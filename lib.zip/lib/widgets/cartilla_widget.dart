import 'package:flutter/material.dart';

class CartillaWidget extends StatelessWidget {
  final List<List<int>> cartilla;
  final int cartillaIndex;
  final List<int> calledNumbers;
  final VoidCallback onCheckBingo;
  final bool showCheckButton;
  final VoidCallback? onRemoveCartilla;

  const CartillaWidget({
    super.key,
    required this.cartilla,
    required this.cartillaIndex,
    required this.calledNumbers,
    required this.onCheckBingo,
    this.showCheckButton = true,
    this.onRemoveCartilla,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      child: Column(
        children: [
          if (showCheckButton) ...[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Cartilla ${cartillaIndex + 1}',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Row(
                  children: [
                    ElevatedButton(
                      onPressed: onCheckBingo,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.teal,
                        foregroundColor: Colors.white,
                      ),
                      child: const Text('Verificar Bingo'),
                    ),
                    if (onRemoveCartilla != null) ...[
                      SizedBox(width: 8),
                      ElevatedButton(
                        onPressed: onRemoveCartilla,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red,
                          foregroundColor: Colors.white,
                        ),
                        child: const Text('Eliminar'),
                      ),
                    ],
                  ],
                ),
              ],
            ),
            const SizedBox(height: 8),
          ] else ...[
            Text(
              'Cartilla ${cartillaIndex + 1}',
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.green,
              ),
            ),
            const SizedBox(height: 8),
          ],
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey.shade400),
              borderRadius: BorderRadius.circular(8),
              color: Colors.white,
            ),
            child: Column(
              children: List.generate(5, (row) {
                return Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(5, (col) {
                    int number = cartilla[row][col];
                    bool isCalled = calledNumbers.contains(number);
                    bool isFree = number == 0;
                    
                    return Container(
                      width: showCheckButton ? 40 : 50,
                      height: showCheckButton ? 40 : 50,
                      margin: const EdgeInsets.all(1),
                      decoration: BoxDecoration(
                        color: isFree 
                          ? Colors.yellow.shade200
                          : isCalled 
                            ? Colors.green 
                            : Colors.white,
                        border: Border.all(color: Colors.grey.shade400),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Center(
                        child: Text(
                          isFree ? 'FREE' : number.toString(),
                          style: TextStyle(
                            fontSize: showCheckButton ? 10 : 14,
                            fontWeight: FontWeight.bold,
                            color: isFree 
                              ? Colors.black 
                              : isCalled 
                                ? Colors.white 
                                : Colors.black,
                          ),
                        ),
                      ),
                    );
                  }),
                );
              }),
            ),
          ),
        ],
      ),
    );
  }
} 