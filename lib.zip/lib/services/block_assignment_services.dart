// Exportar todos los servicios de asignación por bloques
export 'block_assignment_service.dart';
