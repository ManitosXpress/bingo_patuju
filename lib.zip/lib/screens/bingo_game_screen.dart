import 'package:flutter/material.dart';
import '../models/bingo_game.dart';
import '../widgets/numbers_panel.dart';
import '../widgets/control_panel.dart';

class BingoGameScreen extends StatefulWidget {
  const BingoGameScreen({super.key});

  @override
  State<BingoGameScreen> createState() => _BingoGameScreenState();
}

class _BingoGameScreenState extends State<BingoGameScreen> {
  late BingoGame _bingoGame;

  @override
  void initState() {
    super.initState();
    _bingoGame = BingoGame();
  }

  void _onGameStateChanged() {
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bingo 5x5 - 75 Números'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: Row(
        children: [
          // Panel izquierdo - Todos los números del bingo
          Expanded(
            flex: 1,
            child: NumbersPanel(
              allNumbers: _bingoGame.allNumbers,
              calledNumbers: _bingoGame.calledNumbers,
            ),
          ),
          
          // Panel central - Bola actual y controles
          Expanded(
            flex: 1,
            child: ControlPanel(
              bingoGame: _bingoGame,
              onStateChanged: _onGameStateChanged,
            ),
          ),
        ],
      ),
    );
  }
} 