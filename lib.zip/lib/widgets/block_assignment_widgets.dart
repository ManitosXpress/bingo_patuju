// Exportar todos los widgets de asignación por bloques
export 'block_assignment_config_widget.dart';
export 'block_assignment_summary_widget.dart';
export 'block_assignment_modal.dart';
