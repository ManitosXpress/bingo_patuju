import 'dart:math';

class BingoGame {
  List<int> allNumbers = List.generate(75, (index) => index + 1);
  List<int> calledNumbers = [];
  List<int> availableNumbers = List.generate(75, (index) => index + 1);
  List<List<List<int>>> cartillas = [];
  int currentBall = 0;
  final Random random = Random();

  BingoGame() {
    generateCartillas(5); // Generar 5 cartillas por defecto
  }

  void generateCartillas(int count) {
    cartillas.clear();
    for (int i = 0; i < count; i++) {
      cartillas.add(generateSingleCartilla());
    }
  }

  List<List<int>> generateSingleCartilla() {
    List<List<int>> cartilla = List.generate(5, (index) => List.filled(5, 0));
    
    // Generar números para cada columna según las reglas del bingo
    for (int col = 0; col < 5; col++) {
      List<int> columnNumbers = [];
      int startNum = col * 15 + 1;
      int endNum = (col + 1) * 15;
      
      // Generar 5 números únicos para esta columna
      while (columnNumbers.length < 5) {
        int num = random.nextInt(endNum - startNum + 1) + startNum;
        if (!columnNumbers.contains(num)) {
          columnNumbers.add(num);
        }
      }
      
      // Colocar los números en la columna
      for (int row = 0; row < 5; row++) {
        cartilla[row][col] = columnNumbers[row];
      }
    }
    
    // El centro es libre (número 0)
    cartilla[2][2] = 0;
    
    return cartilla;
  }

  void callNextBall() {
    if (availableNumbers.isNotEmpty) {
      int randomIndex = random.nextInt(availableNumbers.length);
      int ball = availableNumbers[randomIndex];
      
      currentBall = ball;
      calledNumbers.add(ball);
      availableNumbers.removeAt(randomIndex);
    }
  }

  void resetGame() {
    calledNumbers.clear();
    availableNumbers = List.generate(75, (index) => index + 1);
    currentBall = 0;
    generateCartillas(5); // Generar nuevas cartillas al resetear
  }

  void shuffleNumbers() {
    availableNumbers.shuffle(random);
  }

  bool checkBingo(List<List<int>> cartilla) {
    // Verificar filas
    for (int row = 0; row < 5; row++) {
      bool rowComplete = true;
      for (int col = 0; col < 5; col++) {
        if (cartilla[row][col] != 0 && !calledNumbers.contains(cartilla[row][col])) {
          rowComplete = false;
          break;
        }
      }
      if (rowComplete) return true;
    }

    // Verificar columnas
    for (int col = 0; col < 5; col++) {
      bool colComplete = true;
      for (int row = 0; row < 5; row++) {
        if (cartilla[row][col] != 0 && !calledNumbers.contains(cartilla[row][col])) {
          colComplete = false;
          break;
        }
      }
      if (colComplete) return true;
    }

    // Verificar diagonales
    bool diagonal1Complete = true;
    bool diagonal2Complete = true;
    
    for (int i = 0; i < 5; i++) {
      if (cartilla[i][i] != 0 && !calledNumbers.contains(cartilla[i][i])) {
        diagonal1Complete = false;
      }
      if (cartilla[i][4-i] != 0 && !calledNumbers.contains(cartilla[i][4-i])) {
        diagonal2Complete = false;
      }
    }
    
    return diagonal1Complete || diagonal2Complete;
  }

  bool isNumberCalled(int number) {
    return calledNumbers.contains(number);
  }

  int get currentBallNumber => currentBall;
  int get totalCalledNumbers => calledNumbers.length;
  int get remainingNumbers => availableNumbers.length;
  int get totalCartillas => cartillas.length;
} 