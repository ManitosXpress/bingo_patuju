// Exportar todos los modelos de asignación por bloques
export 'block_assignment_config.dart';
