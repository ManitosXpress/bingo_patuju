// Exportar toda la funcionalidad de asignación por bloques
export 'models/block_assignment_models.dart';
export 'services/block_assignment_services.dart';
export 'widgets/block_assignment_widgets.dart';
