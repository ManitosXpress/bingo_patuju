import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import '../models/bingo_game.dart';
import 'cartilla_widget.dart';

class ControlPanel extends StatefulWidget {
  final BingoGame bingoGame;
  final VoidCallback onStateChanged;

  const ControlPanel({
    super.key,
    required this.bingoGame,
    required this.onStateChanged,
  });

  @override
  State<ControlPanel> createState() => _ControlPanelState();
}

class _ControlPanelState extends State<ControlPanel> {
  String _getColumnLetter(int number) {
    if (number >= 1 && number <= 15) return 'B';
    if (number >= 16 && number <= 30) return 'I';
    if (number >= 31 && number <= 45) return 'N';
    if (number >= 46 && number <= 60) return 'G';
    if (number >= 61 && number <= 75) return 'O';
    return '';
  }

  String _formatBallNumber(int number) {
    String letter = _getColumnLetter(number);
    return '$letter$number';
  }

  void _callNextBall() {
    widget.bingoGame.callNextBall();
    widget.onStateChanged();
    
    // Verificar automáticamente si hay bingo después de cantar la bola
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _checkBingoAutomatically();
    });
  }

  void _resetGame() {
    widget.bingoGame.resetGame();
    widget.onStateChanged();
  }

  void _shuffleNumbers() {
    widget.bingoGame.shuffleNumbers();
    widget.onStateChanged();
  }

  void _checkBingo() {
    // Verificar todas las cartillas
    for (int i = 0; i < widget.bingoGame.cartillas.length; i++) {
      if (widget.bingoGame.checkBingo(widget.bingoGame.cartillas[i])) {
        _showBingoDialog(i);
        return;
      }
    }
    
    // Si no hay bingo, mostrar mensaje
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('No hay bingo aún. ¡Sigue cantando bolas!'),
        backgroundColor: Colors.orange,
      ),
    );
  }

  void _checkBingoAutomatically() {
    // Verificar todas las cartillas
    for (int i = 0; i < widget.bingoGame.cartillas.length; i++) {
      if (widget.bingoGame.checkBingo(widget.bingoGame.cartillas[i])) {
        _showBingoDialog(i);
        return;
      }
    }
  }

  void _showBingoDialog(int cartillaIndex) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Row(
            children: [
              Icon(Icons.celebration, color: Colors.green, size: 30),
              SizedBox(width: 10),
              Text('¡BINGO!'),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '¡La cartilla ${cartillaIndex + 1} tiene BINGO!',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 20),
              CartillaWidget(
                cartilla: widget.bingoGame.cartillas[cartillaIndex],
                cartillaIndex: cartillaIndex,
                calledNumbers: widget.bingoGame.calledNumbers,
                onCheckBingo: () {}, // No necesitamos acción aquí
                showCheckButton: false, // No mostrar el botón en el diálogo
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cerrar'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                _resetGame();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
              ),
              child: Text('Nuevo Juego'),
            ),
          ],
        );
      },
    );
  }

  void _showAllCartillas() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: Row(
                children: [
                  Icon(Icons.grid_on, color: Colors.blue, size: 30),
                  SizedBox(width: 10),
                  Text('Todas las Cartillas'),
                ],
              ),
              content: Container(
                width: MediaQuery.of(context).size.width * 0.8,
                height: MediaQuery.of(context).size.height * 0.7,
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Cartillas generadas: ${widget.bingoGame.totalCartillas}',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                        ElevatedButton.icon(
                          onPressed: () {
                            _addNewCartilla();
                            setState(() {}); // Actualizar el diálogo
                          },
                          icon: const Icon(Icons.add),
                          label: const Text('Nueva Cartilla'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green,
                            foregroundColor: Colors.white,
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 16),
                    Expanded(
                      child: ListView.builder(
                        itemCount: widget.bingoGame.cartillas.length,
                        itemBuilder: (context, index) {
                          return CartillaWidget(
                            cartilla: widget.bingoGame.cartillas[index],
                            cartillaIndex: index,
                            calledNumbers: widget.bingoGame.calledNumbers,
                            onCheckBingo: () {
                              Navigator.of(context).pop();
                              _checkBingo();
                            },
                            showCheckButton: true,
                            onRemoveCartilla: () {
                              _removeCartilla(index);
                              setState(() {}); // Actualizar el diálogo
                            },
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text('Cerrar'),
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    _resetGame();
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    foregroundColor: Colors.white,
                  ),
                  child: Text('Nuevas Cartillas'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  void _addNewCartilla() {
    widget.bingoGame.cartillas.add(widget.bingoGame.generateSingleCartilla());
    widget.onStateChanged();
  }

  void _removeCartilla(int index) {
    if (widget.bingoGame.cartillas.length > 1) {
      widget.bingoGame.cartillas.removeAt(index);
      widget.onStateChanged();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Debe haber al menos una cartilla'),
          backgroundColor: Colors.orange,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          // Bola actual
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              color: widget.bingoGame.currentBallNumber > 0 ? Colors.red : Colors.grey.shade300,
              shape: BoxShape.circle,
              border: Border.all(color: Colors.grey.shade400, width: 3),
            ),
            child: Center(
              child: Text(
                widget.bingoGame.currentBallNumber > 0 ? _formatBallNumber(widget.bingoGame.currentBallNumber) : '?',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: widget.bingoGame.currentBallNumber > 0 ? Colors.white : Colors.grey,
                ),
              ),
            ),
          ),
          
          const SizedBox(height: 20),
          
          // Botones de control
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              ElevatedButton.icon(
                onPressed: _callNextBall,
                icon: const Icon(Icons.play_arrow),
                label: const Text('Cantar Bola'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                ),
              ),
              ElevatedButton.icon(
                onPressed: _checkBingo,
                icon: const Icon(Icons.search),
                label: const Text('Verificar Bingo'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.teal,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 10),
          
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              ElevatedButton.icon(
                onPressed: _showAllCartillas,
                icon: const Icon(Icons.grid_on),
                label: const Text('Ver Cartillas'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.indigo,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                ),
              ),
              ElevatedButton.icon(
                onPressed: _resetGame,
                icon: const Icon(Icons.refresh),
                label: const Text('Resetear'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.orange,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                ),
              ),
              ElevatedButton.icon(
                onPressed: _shuffleNumbers,
                icon: const Icon(Icons.shuffle),
                label: const Text('Barajar'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.purple,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 20),
          
          // Información del juego
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.blue.shade50,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.blue.shade200),
            ),
            child: Column(
              children: [
                Text(
                  'Bolas cantadas: ${widget.bingoGame.totalCalledNumbers}',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 8),
                Text(
                  'Bolas restantes: ${widget.bingoGame.remainingNumbers}',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 8),
                Text(
                  'Cartillas generadas: ${widget.bingoGame.totalCartillas}',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 20),
          
          // Bolas cantadas recientemente
          const Text(
            'Bolas Cantadas',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.grey.shade300),
              ),
              child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 10,
                  childAspectRatio: 1,
                  crossAxisSpacing: 4,
                  mainAxisSpacing: 4,
                ),
                itemCount: widget.bingoGame.calledNumbers.length,
                itemBuilder: (context, index) {
                  return Container(
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Center(
                      child: Text(
                        _formatBallNumber(widget.bingoGame.calledNumbers[widget.bingoGame.calledNumbers.length - 1 - index]),
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
} 